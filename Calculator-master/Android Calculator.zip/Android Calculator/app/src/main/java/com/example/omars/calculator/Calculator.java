package com.example.omars.calculator;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Calculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculator_activity);
//adds the buttons to an array
        btns.add((Button) (findViewById(R.id.btn0)));//0
        btns.add((Button) (findViewById(R.id.btn1)));//1
        btns.add((Button) (findViewById(R.id.btn2)));//2
        btns.add((Button) (findViewById(R.id.btn3)));//3
        btns.add((Button) (findViewById(R.id.btn4)));//4
        btns.add((Button) (findViewById(R.id.btn5)));//5
        btns.add((Button) (findViewById(R.id.btn6)));//6
        btns.add((Button) (findViewById(R.id.btn7)));//7
        btns.add((Button) (findViewById(R.id.btn8)));//8
        btns.add((Button) (findViewById(R.id.btn9)));//9
        btns.add((Button) (findViewById(R.id.btnTimes)));//10
        btns.add((Button) (findViewById(R.id.btnNeg)));//11
        btns.add((Button) (findViewById(R.id.btnPlus)));//12
        btns.add((Button) (findViewById(R.id.btnPI)));//13
        btns.add((Button) (findViewById(R.id.btnPeriod)));//14
        btns.add((Button) (findViewById(R.id.btnMinus)));//15
        btns.add((Button) (findViewById(R.id.btnEquals)));//16
        btns.add((Button) (findViewById(R.id.btnDiv)));//17
        btns.add((Button) (findViewById(R.id.btnDel)));//18
        btns.add((Button) (findViewById(R.id.btnAC)));//19

        lblProblem = (TextView) findViewById(R.id.lblProblem);//adds the 2 labels
        lblAnswer= (TextView) findViewById(R.id.lblAnswer);
    }

    ArrayList<Button> btns = new ArrayList();//array of buttons
    public TextView lblProblem, lblAnswer;//labels to display the answer and the problem
    private int twoNeg = 0;

    public void btnClick(View v)//method that will be executed after a button click
    {
        System.out.println(twoNeg);
        if(v == btns.get(19)){//condition to check if they clicked All Clear
            lblProblem.setText("");//empties the problem
            return;
        }else if(v == btns.get(18)){//condition to check if they clicked delete
            if(lblProblem.getText().length() != 0){//condition to check if there is anything in the label
                deleteLN();
            }
            return;
        }else if(v == btns.get(11) || v == btns.get(15)){//condition to check if they clicked negative button
            lblProblem.setText(lblProblem.getText() + "-");
            twoNeg++;
            checkTN();
            return;
        }else {
            for (int i = 0; i < btns.size(); ++i) {//loop to check which button was clicked
                if (v == btns.get(i)) {
                    twoNeg = 0;
                    lblProblem.setText(lblProblem.getText() + btns.get(i).getText().toString());//adds that number to the problem
                }
            }
        }

    }

    public void checkTN(){//check if there is two consecutive negatives
        if(twoNeg == 2){
            twoNeg = 0;
            deleteLN();//delets the 2 negatives
            deleteLN();
            lblProblem.setText(lblProblem.getText() + "+");//adds a positive sign
        }
    }

    public void deleteLN(){
        lblProblem.setText(lblProblem.getText().toString().substring(0,lblProblem.length()-1));//deletes the last number that the user input
    }


}
